/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Users;

import Users.*;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Scanner;
/**
 *
 * @author simonnewham
 */
public class Convenor extends User{
    public String convenorSubject;
    
    
    public Convenor(String u,String f, String l,  String e, String p, String r){
        
        super(u, f, l, e, p, r);
       
    }
    
    public static void importMarks(String fileName, String assessName) throws FileNotFoundException, IOException, SQLException{
        
        
        Scanner s = new Scanner(new File(fileName));
        
        Connection myConn = DriverManager.getConnection("jdbc:mysql://localhost:3306/users", "root", "capstone"); 
        Statement myStatement = myConn.createStatement();
        String insertColumn =   "ALTER TABLE users.marks ADD "+ assessName +" INT";
                    
        myStatement.executeUpdate(insertColumn);        
        while (s.hasNext()){
            String tempString = s.next();
            String[] lineParts = tempString.split(";");
            String studentName = lineParts[0];
            String testMarkString = lineParts[1];
            int testMark = Integer.parseInt(testMarkString);
            
            String insertMark = "UPDATE users.marks SET " + assessName + "='" + testMarkString + "' WHERE studentname='" + studentName + "' and coursename ='CSC3003S'";
            myStatement.executeUpdate(insertMark);    
        }
        myConn.close();
        
    }
    
    public static void editMarks(String studentName, String markInfo, String newMark) throws SQLException{
        Connection myConn = DriverManager.getConnection("jdbc:mysql://localhost:3306/users", "root", "capstone"); 
        Statement myStatement = myConn.createStatement();
        
        String editMark = "UPDATE users.marks SET " + markInfo + "='" + newMark + "' WHERE studentname='" + studentName + "' and coursename ='CSC3003S'";
        myStatement.executeUpdate(editMark);
        myConn.close();
    }
    
}
