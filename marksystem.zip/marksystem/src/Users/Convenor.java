/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Users;

import Users.*;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Scanner;
/**
 *
 * @author simonnewham
 */
public class Convenor extends User{
    
    
    public Convenor(String u,String f, String l,  String e, String p, String r){
        
        super(u, f, l, e, p, r);
       
    }
    
    public static void importMarks(String fileName) throws FileNotFoundException, IOException, SQLException{
        
        BufferedReader br = new BufferedReader(new FileReader(fileName));
        String currentLine;
        
        Connection myConn = DriverManager.getConnection("jdbc:mysql://localhost:3306/users", "root", "capstone"); 
        Statement myStatement = myConn.createStatement();
        Scanner s = new Scanner(new File(fileName));
        
        String testName = s.next();
        String insertColumn =   "ALTER TABLE users.marks ADD "+ testName +" INT";
                    
        myStatement.executeUpdate(insertColumn);        
        while (s.hasNext()){
            System.out.println(s.next());
            String[] lineParts;
            String studentName;
            String testMarkString;
            int testMark;
            
            //String insertMark = "UPDATE users.marks SET " + testName + "='" + testMarkString + "' WHERE studentname='" + studentName + "' and coursename ='CSC3003S'";
            //myStatement.executeUpdate(insertMark);    
        }
        myConn.close();
        
    }
    
    public static void editMarks(String studentName, String markInfo, String newMark) throws SQLException{
        Connection myConn = DriverManager.getConnection("jdbc:mysql://localhost:3306/users", "root", "simnew96"); 
        Statement myStatement = myConn.createStatement();
        
        String editMark = "UPDATE users.marks SET " + markInfo + "='" + newMark + "' WHERE studentname='" + studentName + "' and coursename ='CSC3003S'";
        myStatement.executeUpdate(editMark);
        myConn.close();
    }
    
}
