/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UI;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.MenuButton;
import javafx.scene.control.MenuItem;
import javafx.scene.control.SplitMenuButton;
import javafx.scene.control.TextField;

/**
 * FXML Controller class
 *
 * @author simonnewham
 */
public class AS_NewCourseController implements Initializable {

    /**
     * Initializes the controller class.
     */
    
    @FXML private TextField courseName;
    @FXML private TextField courseYear;
    @FXML private Button addCourse;
    @FXML private MenuButton convenorButton;
     
    
    @FXML   
     public void handleAddMarks(ActionEvent event) throws IOException, SQLException{
         
         Users.AdminStaff.addCourse(courseName.getText(), courseYear.getText());
         courseName.clear();
         courseYear.clear();
     }
     
      @FXML   
     public void handleConvenorButton(ActionEvent event) throws IOException, SQLException{
         convenorButton.getItems().add(new MenuItem("test1"));
         convenorButton.getItems().add(new MenuItem("test2"));
     }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
       
    }    
    
}
